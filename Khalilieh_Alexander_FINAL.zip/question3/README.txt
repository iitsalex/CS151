Included question3 as well as WordCount
User can choose to do java question3 <arguments>
OR
User can choose to do java WordCount <arguments>
